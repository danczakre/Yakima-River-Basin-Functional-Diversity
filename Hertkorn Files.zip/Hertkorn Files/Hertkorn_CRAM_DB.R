### Generate metadata for CRAM-like compounds

data = read.csv("~/Documents/Miscellaneous Items/Hertkorn_CRAM_Table.csv")
data$N = 0
data$S = 0
data$P = 0

# Define functions
calc_ai.mod = function(data){
  x = with(data, (1+C-(0.5*O)-S-(0.5*(N+P+H)))/(C-(0.5*O)-S-N-P))
  return(x)
}

calc_nosc = function(data){
  x = with(data, (4-(((4*C)+H-(3*N)-(2*O)+(5*P)-(2*S))/C)))
  return(x)
}

calc_dbe = function(data){
  x = with(data, (1+C-O-S-(0.5*(N+P+H))))
  return(x)
}

calc_ratios = function(data){
  x = data.frame(HtoC_ratio = with(data, H/C), 
                 OtoC_ratio = with(data, O/C))
  data = cbind(data, x)
  return(data)
}

# Run functions
data$AI_Mod = calc_ai.mod(data)
data$DBE = calc_dbe(data)
data$NOSC = calc_nosc(data)
data = calc_ratios(data)
data = data[,-2:-4]

# Write database
write.csv(data, "~/Databases/Hertkorn_CRAM_DB.csv", quote = F, row.names = F)
